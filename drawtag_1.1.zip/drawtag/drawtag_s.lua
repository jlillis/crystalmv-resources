function initDrawTag()
	initSpraying()
end
addEventHandler("onResourceStart",resourceRoot,initDrawTag)


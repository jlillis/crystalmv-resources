function initNPCHLC()
	initNPCControl()
end
addEventHandler("onClientResourceStart",resourceRoot,initNPCHLC)

